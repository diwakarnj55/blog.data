from django.shortcuts import render, redirect
from . models import Apply, Comment
from . forms import ContactForm, ApplyForm, CommentForm

def index(request):
    app=Apply.objects.all()
    data ={
        "app":app
    }
    return render(request,"index.html",data)
def post(request, id):
    app=Apply.objects.get(id=id)
    comm=Comment.objects.all()
    co=CommentForm()
    data ={
        "app":app,
        "co":co,
        "comm":comm,
    }
    if request.method=="POST":
        comment=CommentForm(request.POST)
        if comment.is_valid():
            comment.save()
            return redirect("home")
    return render(request,"post.html",data)
def contact(request):
    con=ContactForm()
    data1 ={
        "con":con,
    }
    if request.method=="POST":
        Contact=ContactForm(request.POST)
        if Contact.is_valid():
            Contact.save()
            return redirect("home")
    return render(request,"contact.html",data1)
def create(request):
    app1=ApplyForm()
    data2 ={
        "app1":app1,
    }
    if request.method=="POST":
        Apply=ApplyForm(request.POST, request.FILES)
        if Apply.is_valid():
            Apply.save()
            return redirect("home")
    return render(request,"create.html",data2)
def about(request):
    return render(request,"about.html")


